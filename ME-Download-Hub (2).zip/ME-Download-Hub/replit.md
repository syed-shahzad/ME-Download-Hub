# ME Downloader - Universal Video Downloader

## Overview

ME Downloader is a web-based video downloading service that allows users to download videos from 1000+ supported websites including YouTube, TikTok, Facebook, Twitter, Instagram, Reddit, Vimeo, and many more. The application provides a clean, user-friendly interface with a Flask backend that leverages yt-dlp for video extraction and downloading.

## System Architecture

### Frontend Architecture
- **Technology**: Pure HTML5, CSS3, and vanilla JavaScript
- **Design**: Responsive design with mobile-first approach
- **CSS Framework**: Custom CSS with CSS variables for theming
- **Font**: Google Fonts (Inter) with Font Awesome icons
- **Structure**: Multi-page application with shared navigation and styling

### Backend Architecture
- **Framework**: Flask (Python web framework)
- **Video Processing**: yt-dlp library for video extraction
- **CORS**: Flask-CORS for cross-origin resource sharing
- **File Handling**: Temporary file system for downloads
- **API**: RESTful endpoints for video processing

## Key Components

### Frontend Components
1. **Static Pages**:
   - `index.html` - Main landing page with download interface
   - `about.html` - About us page
   - `contact.html` - Contact form page
   - `privacy-policy.html` - Privacy policy page
   - `terms.html` - Terms and conditions page

2. **Styling**:
   - `style.css` - Comprehensive CSS with custom properties
   - Responsive design with mobile navigation
   - Professional color scheme and typography

3. **JavaScript**:
   - `main.js` - Interactive functionality
   - Form handling and validation
   - Navigation and UI interactions

### Backend Components
1. **Flask Application**:
   - `server.py` - Main Flask server serving static files and API
   - `app.py` - Alternative backend implementation
   - Static file serving and API endpoints

2. **Video Processing**:
   - `VideoDownloader` class for handling video operations
   - Support for 1000+ websites through yt-dlp
   - Metadata extraction and format selection

## Data Flow

1. **User Input**: User enters video URL on frontend
2. **URL Validation**: Frontend validates URL format
3. **API Request**: JavaScript sends POST request to Flask backend
4. **Video Processing**: Backend uses yt-dlp to extract video information
5. **Download**: Backend processes and serves video file
6. **Response**: Frontend receives download link or error message

## External Dependencies

### Python Dependencies
- **Flask**: Web framework for backend API
- **Flask-CORS**: Cross-origin resource sharing
- **yt-dlp**: Video extraction library (supports 1000+ sites)

### Frontend Dependencies
- **Google Fonts**: Inter font family
- **Font Awesome**: Icon library (CDN)
- **No JavaScript frameworks**: Pure vanilla JavaScript

### Supported Platforms
- YouTube, TikTok, Facebook, Twitter, Instagram
- Reddit, Vimeo, Twitch, Dailymotion, LinkedIn
- Pinterest, SoundCloud, Mixcloud, BitChute
- News sites (CNN, BBC, Reuters, Bloomberg)
- Educational platforms (TED, Coursera, Udemy)
- And 1000+ more supported by yt-dlp

## Deployment Strategy

### Static File Serving
- Flask serves static HTML, CSS, and JS files
- All frontend assets served from root directory
- SEO-optimized with proper meta tags and schema markup

### Backend Deployment
- Flask application can be deployed on any Python-compatible hosting
- Temporary file system for download processing
- CORS enabled for frontend-backend communication

### SEO Considerations
- Comprehensive meta tags for all pages
- Open Graph and Twitter Card support
- Schema markup for rich snippets
- Robots.txt for search engine crawling

## Recent Changes

### July 07, 2025
- **Security Fix**: Fixed XSS vulnerability in notification system by replacing unsafe innerHTML with secure DOM methods
- **Critical Security Patch**: Fixed XSS vulnerability in download options modal (lines 487-538) by:
  - Removing user-controlled data from innerHTML template
  - Using textContent instead of innerHTML for video metadata display
  - Preventing malicious script injection through video titles and uploader names
- **YouTube Fix**: Resolved YouTube download format availability errors with flexible fallback options
- **Enhanced Download Flow**: Added comprehensive download process with multiple verification steps:
  - CAPTCHA verification (math-based challenge)
  - Video quality and format selection modal (MP4/MP3, SD/HD/Best/4K)
  - Mandatory ad display before download
- **User Experience**: Improved error handling with user-friendly messages
- **Download Options**: Interactive modal showing video info and format/quality selection
- **Ad Integration**: 15-second ad display with skip functionality after timer completion

## User Preferences

```
Preferred communication style: Simple, everyday language.
```

## Additional Notes

### Security Features
- URL validation before processing
- Temporary file cleanup
- CORS protection
- Input sanitization through yt-dlp

### Performance Considerations
- Temporary file system prevents storage buildup
- Efficient video processing through yt-dlp
- Responsive design for fast loading
- Optimized CSS with custom properties

### Future Enhancements
- The application structure supports easy addition of:
  - User authentication system
  - Download history tracking
  - Premium features
  - Analytics integration
  - Database storage for user data

The application is designed to be scalable and maintainable, with clear separation between frontend and backend concerns, making it easy to extend and modify as needed.