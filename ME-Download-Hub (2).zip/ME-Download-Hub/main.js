/**
 * ME Downloader - Main JavaScript File
 * Handles all interactive functionality for the video downloader website
 */

// DOM Content Loaded Event
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

/**
 * Initialize the application
 */
function initializeApp() {
    initializeNavigation();
    initializeDownloadForm();
    initializeContactForm();
    initializePlatformButtons();
    initializeFormatButtons();
    initializeQualityButtons();
    initializeModals();
    initializeSmoothScrolling();
    initializeAnimations();
}

/**
 * Navigation functionality
 */
function initializeNavigation() {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function() {
            navToggle.classList.toggle('active');
            navMenu.classList.toggle('active');
        });

        // Close mobile menu when clicking on links
        const navLinks = document.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', function() {
                navToggle.classList.remove('active');
                navMenu.classList.remove('active');
            });
        });

        // Close mobile menu when clicking outside
        document.addEventListener('click', function(e) {
            if (!navToggle.contains(e.target) && !navMenu.contains(e.target)) {
                navToggle.classList.remove('active');
                navMenu.classList.remove('active');
            }
        });
    }

    // Sticky header effect
    const header = document.querySelector('.header');
    if (header) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 100) {
                header.style.background = 'hsl(var(--surface) / 0.95)';
                header.style.backdropFilter = 'blur(10px)';
            } else {
                header.style.background = 'hsl(var(--surface) / 0.95)';
                header.style.backdropFilter = 'blur(8px)';
            }
        });
    }
}

/**
 * Platform button functionality
 */
function initializePlatformButtons() {
    const platformButtons = document.querySelectorAll('.platform-btn');
    
    platformButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Remove active class from all buttons
            platformButtons.forEach(btn => btn.classList.remove('active'));
            
            // Add active class to clicked button
            this.classList.add('active');
            
            // Update placeholder text based on selected platform
            const platform = this.dataset.platform;
            const urlInput = document.getElementById('videoUrl');
            
            if (urlInput) {
                const placeholders = {
                    youtube: 'Paste YouTube URL here (e.g., https://www.youtube.com/watch?v=...)',
                    tiktok: 'Paste TikTok URL here (e.g., https://www.tiktok.com/@user/video/...)',
                    facebook: 'Paste Facebook video URL here (e.g., https://www.facebook.com/...)',
                    twitter: 'Paste Twitter/X video URL here (e.g., https://twitter.com/...)',
                    instagram: 'Paste Instagram video URL here (e.g., https://www.instagram.com/p/...)',
                    reddit: 'Paste Reddit video URL here (e.g., https://www.reddit.com/r/.../...)',
                    vimeo: 'Paste Vimeo URL here (e.g., https://vimeo.com/...)',
                    twitch: 'Paste Twitch clip URL here (e.g., https://clips.twitch.tv/...)',
                    any: 'Paste any website video URL here - we support 1000+ websites!'
                };
                
                urlInput.placeholder = placeholders[platform] || 'Paste video URL here...';
            }
        });
    });
}

/**
 * Format button functionality
 */
function initializeFormatButtons() {
    const formatButtons = document.querySelectorAll('.format-btn');
    const qualityGroup = document.querySelector('.option-group:has(.quality-buttons)');
    
    formatButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Remove active class from all buttons
            formatButtons.forEach(btn => btn.classList.remove('active'));
            
            // Add active class to clicked button
            this.classList.add('active');
            
            // Show/hide quality options based on format
            const format = this.dataset.format;
            if (qualityGroup) {
                if (format === 'mp3') {
                    qualityGroup.style.display = 'none';
                } else {
                    qualityGroup.style.display = 'block';
                }
            }
        });
    });
}

/**
 * Quality button functionality
 */
function initializeQualityButtons() {
    const qualityButtons = document.querySelectorAll('.quality-btn');
    
    qualityButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Remove active class from all buttons
            qualityButtons.forEach(btn => btn.classList.remove('active'));
            
            // Add active class to clicked button
            this.classList.add('active');
        });
    });
}

/**
 * Download form functionality
 */
function initializeDownloadForm() {
    const downloadBtn = document.getElementById('downloadBtn');
    const urlInput = document.getElementById('videoUrl');
    
    if (downloadBtn && urlInput) {
        downloadBtn.addEventListener('click', function() {
            handleVideoDownload();
        });

        // Allow Enter key to trigger download
        urlInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                handleVideoDownload();
            }
        });

        // Real-time URL validation
        urlInput.addEventListener('input', function() {
            validateVideoUrl(this.value);
        });
    }
}

/**
 * Handle video download process
 */
async function handleVideoDownload() {
    const urlInput = document.getElementById('videoUrl');
    const downloadBtn = document.getElementById('downloadBtn');
    const url = urlInput.value.trim();
    
    if (!url) {
        showNotification('Please enter a video URL', 'error');
        urlInput.focus();
        return;
    }

    // Show loading state
    downloadBtn.disabled = true;
    downloadBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
    
    try {
        // First, check if URL is valid and get video info
        const checkResponse = await fetch('/api/check-url', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ url: url })
        });
        
        const checkData = await checkResponse.json();
        
        if (!checkResponse.ok) {
            throw new Error(checkData.error || 'Invalid URL');
        }
        
        // Show video info
        showNotification(`Found: ${checkData.info.title} by ${checkData.info.uploader}`, 'info');
        
        // Step 1: Show CAPTCHA verification
        const captchaVerified = await showCaptchaVerification();
        if (!captchaVerified) {
            throw new Error('CAPTCHA verification failed');
        }
        
        // Step 2: Show video quality and format selection
        const downloadOptions = await showDownloadOptionsModal(checkData.info);
        if (!downloadOptions) {
            throw new Error('Download cancelled');
        }
        
        // Step 3: Show ad before download
        downloadBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading ad...';
        await showAdBeforeDownload();
        
        // Step 4: Start actual download
        downloadBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Downloading...';
        
        // Get selected format and quality
        const selectedFormat = document.querySelector('.format-btn.active');
        const selectedQuality = document.querySelector('.quality-btn.active');
        const format = selectedFormat ? selectedFormat.dataset.format : 'mp4';
        const quality = selectedQuality ? selectedQuality.dataset.quality : 'best';

        // Check if 4K Ultra HD is selected - show ads first
        if (quality === '4k') {
            showNotification('Loading 4K Ultra HD download - showing ad...', 'info');
            
            // Show ad modal/overlay
            await showAdForPremiumDownload();
            
            showNotification('Ad completed - starting 4K download...', 'success');
        }

        // Start actual download
        const downloadResponse = await fetch('/api/download', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ 
                url: url,
                format: downloadOptions.format,
                quality: downloadOptions.quality
            })
        });
        
        const downloadData = await downloadResponse.json();
        
        if (!downloadResponse.ok) {
            throw new Error(downloadData.error || 'Download failed');
        }
        
        // Show success message
        showNotification(`Successfully downloaded: ${downloadData.title}`, 'success');
        
        // Trigger file download
        const fileUrl = `/api/file/${downloadData.download_id}`;
        const link = document.createElement('a');
        link.href = fileUrl;
        link.download = `${downloadData.title}.${downloadData.format}`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        // Clear the input
        urlInput.value = '';
        
        // Track download analytics
        trackDownload(checkData.info.platform, url);
        
    } catch (error) {
        console.error('Download error:', error);
        showNotification(error.message || 'Download failed. Please try again.', 'error');
    } finally {
        // Reset button state
        downloadBtn.disabled = false;
        downloadBtn.innerHTML = '<i class="fas fa-download"></i> Download';
    }
}

/**
 * Show CAPTCHA verification
 */
async function showCaptchaVerification() {
    return new Promise((resolve) => {
        const captchaModal = document.createElement('div');
        captchaModal.className = 'captcha-modal-overlay';
        captchaModal.innerHTML = `
            <div class="captcha-modal">
                <div class="captcha-header">
                    <h3><i class="fas fa-shield-alt"></i> Security Verification</h3>
                    <p>Please complete the CAPTCHA to verify you're not a robot</p>
                </div>
                <div class="captcha-content">
                    <div class="captcha-challenge">
                        <div class="math-captcha">
                            <div class="math-problem">
                                <span id="captcha-num1"></span> + <span id="captcha-num2"></span> = ?
                            </div>
                            <input type="number" id="captcha-answer" placeholder="Enter answer" class="captcha-input">
                        </div>
                        <div class="captcha-buttons">
                            <button id="refresh-captcha" class="refresh-btn">
                                <i class="fas fa-refresh"></i> New Challenge
                            </button>
                            <button id="verify-captcha" class="verify-btn">
                                <i class="fas fa-check"></i> Verify
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(captchaModal);
        
        let num1, num2, correctAnswer;
        
        function generateCaptcha() {
            num1 = Math.floor(Math.random() * 10) + 1;
            num2 = Math.floor(Math.random() * 10) + 1;
            correctAnswer = num1 + num2;
            
            document.getElementById('captcha-num1').textContent = num1;
            document.getElementById('captcha-num2').textContent = num2;
            document.getElementById('captcha-answer').value = '';
        }
        
        generateCaptcha();
        
        // Add styles
        const captchaStyles = document.createElement('style');
        captchaStyles.textContent = `
            .captcha-modal-overlay {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.8);
                display: flex;
                justify-content: center;
                align-items: center;
                z-index: 10000;
                animation: fadeIn 0.3s ease;
            }
            
            .captcha-modal {
                background: white;
                border-radius: 12px;
                padding: 30px;
                max-width: 400px;
                width: 90%;
                text-align: center;
                box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
            }
            
            .captcha-header h3 {
                color: #2c5aa0;
                margin-bottom: 10px;
                font-size: 1.5em;
            }
            
            .captcha-header p {
                color: #666;
                margin-bottom: 25px;
            }
            
            .math-captcha {
                background: #f8f9fa;
                padding: 20px;
                border-radius: 8px;
                border: 2px solid #dee2e6;
                margin-bottom: 20px;
            }
            
            .math-problem {
                font-size: 1.5em;
                font-weight: bold;
                color: #2c5aa0;
                margin-bottom: 15px;
            }
            
            .captcha-input {
                width: 100px;
                padding: 10px;
                font-size: 1.2em;
                text-align: center;
                border: 2px solid #dee2e6;
                border-radius: 5px;
                margin-bottom: 15px;
            }
            
            .captcha-buttons {
                display: flex;
                gap: 10px;
                justify-content: center;
            }
            
            .refresh-btn {
                background: #6c757d;
                color: white;
                border: none;
                padding: 10px 15px;
                border-radius: 5px;
                cursor: pointer;
                font-size: 0.9em;
            }
            
            .verify-btn {
                background: #28a745;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 5px;
                cursor: pointer;
                font-size: 0.9em;
            }
            
            .refresh-btn:hover {
                background: #5a6268;
            }
            
            .verify-btn:hover {
                background: #218838;
            }
        `;
        document.head.appendChild(captchaStyles);
        
        // Handle refresh button
        document.getElementById('refresh-captcha').addEventListener('click', generateCaptcha);
        
        // Handle verify button
        document.getElementById('verify-captcha').addEventListener('click', () => {
            const userAnswer = parseInt(document.getElementById('captcha-answer').value);
            if (userAnswer === correctAnswer) {
                document.body.removeChild(captchaModal);
                document.head.removeChild(captchaStyles);
                resolve(true);
            } else {
                showNotification('Incorrect answer. Please try again.', 'error');
                generateCaptcha();
            }
        });
        
        // Handle Enter key
        document.getElementById('captcha-answer').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                document.getElementById('verify-captcha').click();
            }
        });
        
        // Prevent closing modal by clicking outside
        captchaModal.addEventListener('click', (e) => {
            if (e.target === captchaModal) {
                // Don't close - user must complete CAPTCHA
            }
        });
    });
}

/**
 * Show download options modal
 */
async function showDownloadOptionsModal(videoInfo) {
    return new Promise((resolve) => {
        const optionsModal = document.createElement('div');
        optionsModal.className = 'options-modal-overlay';
        optionsModal.innerHTML = `
            <div class="options-modal">
                <div class="options-header">
                    <h3><i class="fas fa-cog"></i> Download Options</h3>
                    <p>Choose your preferred format and quality</p>
                </div>
                <div class="video-preview">
                    <div class="video-info">
                        <h4></h4>
                        <p></p>
                    </div>
                </div>
                <div class="options-content">
                    <div class="format-section">
                        <h4>Format</h4>
                        <div class="format-options">
                            <button class="format-option active" data-format="mp4">
                                <i class="fas fa-video"></i> MP4 Video
                            </button>
                            <button class="format-option" data-format="mp3">
                                <i class="fas fa-music"></i> MP3 Audio
                            </button>
                        </div>
                    </div>
                    <div class="quality-section">
                        <h4>Quality</h4>
                        <div class="quality-options">
                            <button class="quality-option" data-quality="sd">
                                <i class="fas fa-film"></i> SD (480p)
                            </button>
                            <button class="quality-option active" data-quality="hd">
                                <i class="fas fa-tv"></i> HD (720p)
                            </button>
                            <button class="quality-option" data-quality="best">
                                <i class="fas fa-crown"></i> Best Quality
                            </button>
                            <button class="quality-option premium" data-quality="4k">
                                <i class="fas fa-gem"></i> 4K Ultra HD
                            </button>
                        </div>
                    </div>
                </div>
                <div class="options-buttons">
                    <button id="cancel-download" class="cancel-btn">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button id="proceed-download" class="proceed-btn">
                        <i class="fas fa-download"></i> Proceed
                    </button>
                </div>
            </div>
        `;
        
        document.body.appendChild(optionsModal);
        
        // Safely set user-controlled content using textContent to prevent XSS
        const titleElement = optionsModal.querySelector('.video-info h4');
        const infoElement = optionsModal.querySelector('.video-info p');
        titleElement.textContent = videoInfo.title || 'Unknown Title';
        infoElement.textContent = `By: ${videoInfo.uploader || 'Unknown'} • Platform: ${videoInfo.platform || 'Unknown'}`;
        
        // Add styles
        const optionsStyles = document.createElement('style');
        optionsStyles.textContent = `
            .options-modal-overlay {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.8);
                display: flex;
                justify-content: center;
                align-items: center;
                z-index: 10000;
                animation: fadeIn 0.3s ease;
            }
            
            .options-modal {
                background: white;
                border-radius: 12px;
                padding: 30px;
                max-width: 500px;
                width: 90%;
                max-height: 80vh;
                overflow-y: auto;
                box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
            }
            
            .options-header {
                text-align: center;
                margin-bottom: 25px;
            }
            
            .options-header h3 {
                color: #2c5aa0;
                margin-bottom: 10px;
                font-size: 1.5em;
            }
            
            .options-header p {
                color: #666;
                margin-bottom: 0;
            }
            
            .video-preview {
                background: #f8f9fa;
                padding: 20px;
                border-radius: 8px;
                margin-bottom: 25px;
                border: 1px solid #dee2e6;
            }
            
            .video-info h4 {
                color: #2c5aa0;
                margin-bottom: 8px;
                font-size: 1.1em;
                line-height: 1.4;
            }
            
            .video-info p {
                color: #666;
                font-size: 0.9em;
                margin: 0;
            }
            
            .format-section, .quality-section {
                margin-bottom: 25px;
            }
            
            .format-section h4, .quality-section h4 {
                color: #333;
                margin-bottom: 15px;
                font-size: 1.1em;
            }
            
            .format-options, .quality-options {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
                gap: 10px;
            }
            
            .format-option, .quality-option {
                padding: 15px;
                border: 2px solid #dee2e6;
                border-radius: 8px;
                background: white;
                cursor: pointer;
                transition: all 0.3s ease;
                text-align: center;
                font-size: 0.9em;
                display: flex;
                flex-direction: column;
                align-items: center;
                gap: 5px;
            }
            
            .format-option:hover, .quality-option:hover {
                border-color: #2c5aa0;
                background: #f8f9ff;
            }
            
            .format-option.active, .quality-option.active {
                border-color: #2c5aa0;
                background: #2c5aa0;
                color: white;
            }
            
            .quality-option.premium {
                border-color: #ffc107;
                background: linear-gradient(45deg, #fff3cd, #ffffff);
            }
            
            .quality-option.premium:hover {
                border-color: #e0a800;
                background: linear-gradient(45deg, #fff3cd, #ffeaa7);
            }
            
            .quality-option.premium.active {
                border-color: #e0a800;
                background: linear-gradient(45deg, #ffc107, #e0a800);
                color: white;
            }
            
            .options-buttons {
                display: flex;
                gap: 15px;
                justify-content: center;
                margin-top: 25px;
            }
            
            .cancel-btn {
                background: #6c757d;
                color: white;
                border: none;
                padding: 12px 25px;
                border-radius: 6px;
                cursor: pointer;
                font-size: 1em;
                transition: all 0.3s ease;
            }
            
            .proceed-btn {
                background: #28a745;
                color: white;
                border: none;
                padding: 12px 25px;
                border-radius: 6px;
                cursor: pointer;
                font-size: 1em;
                transition: all 0.3s ease;
            }
            
            .cancel-btn:hover {
                background: #5a6268;
            }
            
            .proceed-btn:hover {
                background: #218838;
            }
        `;
        document.head.appendChild(optionsStyles);
        
        let selectedFormat = 'mp4';
        let selectedQuality = 'hd';
        
        // Format selection
        document.querySelectorAll('.format-option').forEach(btn => {
            btn.addEventListener('click', function() {
                document.querySelectorAll('.format-option').forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                selectedFormat = this.dataset.format;
                
                // Hide quality options for MP3
                const qualitySection = document.querySelector('.quality-section');
                if (selectedFormat === 'mp3') {
                    qualitySection.style.display = 'none';
                    selectedQuality = 'best';
                } else {
                    qualitySection.style.display = 'block';
                }
            });
        });
        
        // Quality selection
        document.querySelectorAll('.quality-option').forEach(btn => {
            btn.addEventListener('click', function() {
                document.querySelectorAll('.quality-option').forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                selectedQuality = this.dataset.quality;
            });
        });
        
        // Cancel button
        document.getElementById('cancel-download').addEventListener('click', () => {
            document.body.removeChild(optionsModal);
            document.head.removeChild(optionsStyles);
            resolve(null);
        });
        
        // Proceed button
        document.getElementById('proceed-download').addEventListener('click', () => {
            document.body.removeChild(optionsModal);
            document.head.removeChild(optionsStyles);
            resolve({
                format: selectedFormat,
                quality: selectedQuality
            });
        });
    });
}

/**
 * Show ad before download
 */
async function showAdBeforeDownload() {
    return new Promise((resolve) => {
        const adModal = document.createElement('div');
        adModal.className = 'ad-modal-overlay';
        adModal.innerHTML = `
            <div class="ad-modal">
                <div class="ad-header">
                    <h3><i class="fas fa-heart"></i> Support Our Service</h3>
                    <p>Please watch this short ad to support our free service</p>
                </div>
                <div class="ad-content">
                    <div class="ad-video">
                        <div class="ad-player">
                            <i class="fas fa-play-circle"></i>
                            <p>Your Advertisement</p>
                            <div class="ad-progress">
                                <div class="ad-progress-bar"></div>
                            </div>
                            <div class="ad-timer">Skip in <span id="ad-timer">15</span>s</div>
                        </div>
                    </div>
                    <div class="ad-controls">
                        <button id="skip-ad" class="skip-ad-btn" disabled>
                            <i class="fas fa-forward"></i> Skip Ad
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(adModal);
        
        // Add styles
        const adStyles = document.createElement('style');
        adStyles.textContent = `
            .ad-modal-overlay {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.95);
                display: flex;
                justify-content: center;
                align-items: center;
                z-index: 10000;
                animation: fadeIn 0.3s ease;
            }
            
            .ad-modal {
                background: white;
                border-radius: 12px;
                padding: 30px;
                max-width: 600px;
                width: 90%;
                text-align: center;
                box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
            }
            
            .ad-header h3 {
                color: #2c5aa0;
                margin-bottom: 10px;
                font-size: 1.5em;
            }
            
            .ad-header p {
                color: #666;
                margin-bottom: 25px;
            }
            
            .ad-player {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                padding: 80px 20px;
                border-radius: 12px;
                margin-bottom: 20px;
                position: relative;
                overflow: hidden;
            }
            
            .ad-player i {
                font-size: 4em;
                margin-bottom: 15px;
                opacity: 0.9;
            }
            
            .ad-player p {
                font-size: 1.2em;
                margin-bottom: 20px;
            }
            
            .ad-progress {
                width: 100%;
                height: 4px;
                background: rgba(255, 255, 255, 0.3);
                border-radius: 2px;
                overflow: hidden;
                margin-bottom: 15px;
            }
            
            .ad-progress-bar {
                height: 100%;
                background: #28a745;
                width: 0%;
                transition: width 0.1s ease;
            }
            
            .ad-timer {
                position: absolute;
                top: 15px;
                right: 15px;
                background: rgba(0, 0, 0, 0.7);
                padding: 8px 12px;
                border-radius: 15px;
                font-size: 0.9em;
            }
            
            .skip-ad-btn {
                background: #2c5aa0;
                color: white;
                border: none;
                padding: 12px 30px;
                border-radius: 6px;
                cursor: pointer;
                font-size: 1em;
                transition: all 0.3s ease;
            }
            
            .skip-ad-btn:disabled {
                background: #ccc;
                cursor: not-allowed;
            }
            
            .skip-ad-btn:not(:disabled):hover {
                background: #1e3a5f;
                transform: translateY(-2px);
            }
        `;
        document.head.appendChild(adStyles);
        
        // Start ad timer
        let timeLeft = 15;
        const timerElement = document.getElementById('ad-timer');
        const progressBar = document.querySelector('.ad-progress-bar');
        const skipButton = document.getElementById('skip-ad');
        
        const adTimer = setInterval(() => {
            timeLeft--;
            timerElement.textContent = timeLeft;
            
            // Update progress bar
            const progress = ((15 - timeLeft) / 15) * 100;
            progressBar.style.width = progress + '%';
            
            if (timeLeft <= 0) {
                clearInterval(adTimer);
                skipButton.disabled = false;
                skipButton.innerHTML = '<i class="fas fa-check"></i> Continue to Download';
                skipButton.style.background = '#28a745';
                timerElement.textContent = '0';
                progressBar.style.width = '100%';
            }
        }, 1000);
        
        // Handle skip button
        skipButton.addEventListener('click', () => {
            if (!skipButton.disabled) {
                clearInterval(adTimer);
                document.body.removeChild(adModal);
                document.head.removeChild(adStyles);
                resolve();
            }
        });
        
        // Prevent closing modal
        adModal.addEventListener('click', (e) => {
            if (e.target === adModal) {
                // Don't close - user must watch ad
            }
        });
    });
}

/**
 * Show ad modal for premium 4K downloads
 */
async function showAdForPremiumDownload() {
    return new Promise((resolve) => {
        // Create ad modal overlay
        const adModal = document.createElement('div');
        adModal.className = 'ad-modal-overlay';
        adModal.innerHTML = `
            <div class="ad-modal">
                <div class="ad-header">
                    <h3><i class="fas fa-star"></i> Premium 4K Ultra HD Download</h3>
                    <p>Please watch this short ad to unlock your 4K download</p>
                </div>
                <div class="ad-content">
                    <div class="ad-placeholder">
                        <div class="ad-video-mock">
                            <i class="fas fa-play-circle"></i>
                            <p>Advertisement</p>
                            <div class="ad-timer">Skip in <span id="ad-countdown">15</span>s</div>
                        </div>
                    </div>
                    <div class="ad-controls">
                        <button id="skip-ad" class="skip-ad-btn" disabled>
                            <i class="fas fa-forward"></i> Skip Ad
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(adModal);
        
        // Add modal styles
        const adStyles = document.createElement('style');
        adStyles.textContent = `
            .ad-modal-overlay {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.9);
                display: flex;
                justify-content: center;
                align-items: center;
                z-index: 10000;
                animation: fadeIn 0.3s ease;
            }
            
            .ad-modal {
                background: white;
                border-radius: 12px;
                padding: 30px;
                max-width: 500px;
                width: 90%;
                text-align: center;
                box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
            }
            
            .ad-header h3 {
                color: #2c5aa0;
                margin-bottom: 10px;
                font-size: 1.5em;
            }
            
            .ad-header p {
                color: #666;
                margin-bottom: 20px;
            }
            
            .ad-video-mock {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                padding: 60px 20px;
                border-radius: 8px;
                margin-bottom: 20px;
                position: relative;
            }
            
            .ad-video-mock i {
                font-size: 3em;
                margin-bottom: 10px;
                opacity: 0.8;
            }
            
            .ad-timer {
                position: absolute;
                top: 15px;
                right: 15px;
                background: rgba(0, 0, 0, 0.7);
                padding: 5px 10px;
                border-radius: 15px;
                font-size: 0.9em;
            }
            
            .skip-ad-btn {
                background: #2c5aa0;
                color: white;
                border: none;
                padding: 12px 24px;
                border-radius: 6px;
                cursor: pointer;
                font-size: 1em;
                transition: all 0.3s ease;
            }
            
            .skip-ad-btn:disabled {
                background: #ccc;
                cursor: not-allowed;
            }
            
            .skip-ad-btn:not(:disabled):hover {
                background: #1e3a5f;
                transform: translateY(-2px);
            }
            
            @keyframes fadeIn {
                from { opacity: 0; }
                to { opacity: 1; }
            }
        `;
        document.head.appendChild(adStyles);
        
        // Start countdown timer
        let countdown = 15;
        const countdownElement = document.getElementById('ad-countdown');
        const skipButton = document.getElementById('skip-ad');
        
        const timer = setInterval(() => {
            countdown--;
            countdownElement.textContent = countdown;
            
            if (countdown <= 0) {
                clearInterval(timer);
                skipButton.disabled = false;
                skipButton.innerHTML = '<i class="fas fa-check"></i> Continue to Download';
                skipButton.style.background = '#28a745';
            }
        }, 1000);
        
        // Handle skip button click
        skipButton.addEventListener('click', () => {
            if (!skipButton.disabled) {
                document.body.removeChild(adModal);
                document.head.removeChild(adStyles);
                resolve();
            }
        });
        
        // Prevent closing modal by clicking outside
        adModal.addEventListener('click', (e) => {
            if (e.target === adModal) {
                // Don't close - user must watch ad
            }
        });
    });
}

/**
 * Enhanced URL validation with real-time platform detection
 */
function enhancedUrlValidation(url) {
    // More comprehensive URL patterns for real video detection
    const platformPatterns = {
        youtube: [
            /^(https?:\/\/)?(www\.)?(youtube\.com\/(watch\?v=|embed\/|v\/)|youtu\.be\/)[\w-]+/,
            /^(https?:\/\/)?(m\.)?youtube\.com\/watch\?v=[\w-]+/
        ],
        tiktok: [
            /^(https?:\/\/)?(www\.)?tiktok\.com\/@[\w.-]+\/video\/\d+/,
            /^(https?:\/\/)?(vm\.)?tiktok\.com\/[\w]+/
        ],
        facebook: [
            /^(https?:\/\/)?(www\.)?facebook\.com\/.+\/videos?\/.+/,
            /^(https?:\/\/)?(www\.)?fb\.watch\/[\w-]+/
        ],
        twitter: [
            /^(https?:\/\/)?(www\.)?(twitter\.com|x\.com)\/[\w]+\/status\/\d+/
        ],
        instagram: [
            /^(https?:\/\/)?(www\.)?instagram\.com\/(p|reel|tv)\/[\w-]+/
        ]
    };
    
    for (const [platform, patterns] of Object.entries(platformPatterns)) {
        if (patterns.some(pattern => pattern.test(url))) {
            return { valid: true, platform };
        }
    }
    
    return { valid: false, platform: null };
}

/**
 * Validate video URL
 */
function isValidVideoUrl(url) {
    const urlPatterns = {
        youtube: /^(https?:\/\/)?(www\.)?(youtube\.com\/(watch\?v=|embed\/|v\/)|youtu\.be\/).+/,
        tiktok: /^(https?:\/\/)?(www\.)?tiktok\.com\/@[\w.-]+\/video\/\d+/,
        facebook: /^(https?:\/\/)?(www\.)?facebook\.com\/.+\/videos?\/.+/,
        twitter: /^(https?:\/\/)?(www\.)?(twitter\.com|x\.com)\/.+\/status\/\d+/,
        instagram: /^(https?:\/\/)?(www\.)?instagram\.com\/(p|reel)\/[\w-]+/
    };
    
    // Check if URL matches any platform pattern
    return Object.values(urlPatterns).some(pattern => pattern.test(url));
}

/**
 * Real-time URL validation
 */
function validateVideoUrl(url) {
    const urlInput = document.getElementById('videoUrl');
    const downloadBtn = document.getElementById('downloadBtn');
    
    if (!url) {
        resetUrlValidation();
        return;
    }

    if (isValidVideoUrl(url)) {
        urlInput.style.borderColor = 'hsl(var(--success))';
        downloadBtn.style.opacity = '1';
        
        // Auto-select platform based on URL
        autoSelectPlatform(url);
    } else {
        urlInput.style.borderColor = 'hsl(var(--error))';
        downloadBtn.style.opacity = '0.6';
    }
}

/**
 * Auto-select platform based on URL
 */
function autoSelectPlatform(url) {
    const platformButtons = document.querySelectorAll('.platform-btn');
    let detectedPlatform = null;
    
    if (url.includes('youtube.com') || url.includes('youtu.be')) {
        detectedPlatform = 'youtube';
    } else if (url.includes('tiktok.com')) {
        detectedPlatform = 'tiktok';
    } else if (url.includes('facebook.com')) {
        detectedPlatform = 'facebook';
    } else if (url.includes('twitter.com') || url.includes('x.com')) {
        detectedPlatform = 'twitter';
    } else if (url.includes('instagram.com')) {
        detectedPlatform = 'instagram';
    }
    
    if (detectedPlatform) {
        platformButtons.forEach(btn => btn.classList.remove('active'));
        const targetButton = document.querySelector(`[data-platform="${detectedPlatform}"]`);
        if (targetButton) {
            targetButton.classList.add('active');
            targetButton.click(); // Trigger platform selection
        }
    }
}

/**
 * Reset URL validation styling
 */
function resetUrlValidation() {
    const urlInput = document.getElementById('videoUrl');
    const downloadBtn = document.getElementById('downloadBtn');
    
    if (urlInput) urlInput.style.borderColor = 'hsl(var(--border))';
    if (downloadBtn) downloadBtn.style.opacity = '1';
}

/**
 * Track download analytics (mock)
 */
function trackDownload(platform, url) {
    // In real implementation, this would send analytics to your backend
    console.log(`Download tracked: ${platform} - ${url}`);
    
    // Update download counter in localStorage
    const downloads = JSON.parse(localStorage.getItem('me_downloader_stats') || '{}');
    downloads[platform] = (downloads[platform] || 0) + 1;
    downloads.total = (downloads.total || 0) + 1;
    localStorage.setItem('me_downloader_stats', JSON.stringify(downloads));
}

/**
 * Contact form functionality
 */
function initializeContactForm() {
    const contactForm = document.getElementById('contactForm');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleContactSubmission();
        });

        // Real-time validation
        const inputs = contactForm.querySelectorAll('input, select, textarea');
        inputs.forEach(input => {
            input.addEventListener('blur', function() {
                validateField(this);
            });

            input.addEventListener('input', function() {
                clearFieldError(this);
            });
        });
    }
}

/**
 * Handle contact form submission
 */
function handleContactSubmission() {
    const form = document.getElementById('contactForm');
    const submitBtn = document.getElementById('submitBtn');
    
    // Validate all fields
    const isValid = validateContactForm();
    
    if (!isValid) {
        showNotification('Please correct the errors below', 'error');
        return;
    }

    // Show loading state
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
    
    // Collect form data
    const formData = new FormData(form);
    const contactData = Object.fromEntries(formData.entries());
    
    // Simulate form submission
    setTimeout(() => {
        // Reset form
        form.reset();
        
        // Reset button
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<i class="fas fa-paper-plane"></i> Send Message';
        
        // Show success modal
        showSuccessModal();
        
        // Track contact submission
        trackContactSubmission(contactData.subject);
        
    }, 1500);
}

/**
 * Validate contact form
 */
function validateContactForm() {
    const form = document.getElementById('contactForm');
    const fields = ['name', 'email', 'subject', 'message', 'privacy'];
    let isValid = true;
    
    fields.forEach(fieldName => {
        const field = form.querySelector(`[name="${fieldName}"]`);
        if (field && !validateField(field)) {
            isValid = false;
        }
    });
    
    return isValid;
}

/**
 * Validate individual form field
 */
function validateField(field) {
    const fieldName = field.name;
    const value = field.value.trim();
    let isValid = true;
    let errorMessage = '';
    
    // Clear previous errors
    clearFieldError(field);
    
    switch (fieldName) {
        case 'name':
            if (!value) {
                errorMessage = 'Name is required';
                isValid = false;
            } else if (value.length < 2) {
                errorMessage = 'Name must be at least 2 characters';
                isValid = false;
            }
            break;
            
        case 'email':
            if (!value) {
                errorMessage = 'Email is required';
                isValid = false;
            } else if (!isValidEmail(value)) {
                errorMessage = 'Please enter a valid email address';
                isValid = false;
            }
            break;
            
        case 'subject':
            if (!value) {
                errorMessage = 'Please select a subject';
                isValid = false;
            }
            break;
            
        case 'message':
            if (!value) {
                errorMessage = 'Message is required';
                isValid = false;
            } else if (value.length < 10) {
                errorMessage = 'Message must be at least 10 characters';
                isValid = false;
            }
            break;
            
        case 'privacy':
            if (!field.checked) {
                errorMessage = 'You must agree to the Privacy Policy and Terms';
                isValid = false;
            }
            break;
    }
    
    if (!isValid) {
        showFieldError(field, errorMessage);
    }
    
    return isValid;
}

/**
 * Show field error
 */
function showFieldError(field, message) {
    const errorElement = document.getElementById(field.name + 'Error');
    if (errorElement) {
        errorElement.textContent = message;
        errorElement.style.display = 'block';
    }
    
    field.style.borderColor = 'hsl(var(--error))';
}

/**
 * Clear field error
 */
function clearFieldError(field) {
    const errorElement = document.getElementById(field.name + 'Error');
    if (errorElement) {
        errorElement.textContent = '';
        errorElement.style.display = 'none';
    }
    
    field.style.borderColor = 'hsl(var(--border))';
}

/**
 * Validate email format
 */
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

/**
 * Track contact submission
 */
function trackContactSubmission(subject) {
    console.log(`Contact form submitted: ${subject}`);
    
    // Update contact stats in localStorage
    const stats = JSON.parse(localStorage.getItem('me_downloader_contact_stats') || '{}');
    stats[subject] = (stats[subject] || 0) + 1;
    stats.total = (stats.total || 0) + 1;
    localStorage.setItem('me_downloader_contact_stats', JSON.stringify(stats));
}

/**
 * Modal functionality
 */
function initializeModals() {
    const modals = document.querySelectorAll('.modal');
    const closeButtons = document.querySelectorAll('.modal-btn, [data-close-modal]');
    
    closeButtons.forEach(button => {
        button.addEventListener('click', function() {
            closeModal();
        });
    });
    
    // Close modal when clicking outside
    modals.forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                closeModal();
            }
        });
    });
    
    // Close modal with Escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeModal();
        }
    });
}

/**
 * Show success modal
 */
function showSuccessModal() {
    const modal = document.getElementById('successModal');
    if (modal) {
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
}

/**
 * Close modal
 */
function closeModal() {
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        modal.classList.remove('active');
    });
    document.body.style.overflow = '';
}

/**
 * Smooth scrolling functionality
 */
function initializeSmoothScrolling() {
    const links = document.querySelectorAll('a[href^="#"]');
    
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            
            if (href === '#') return;
            
            const target = document.querySelector(href);
            if (target) {
                e.preventDefault();
                
                const headerHeight = document.querySelector('.header').offsetHeight;
                const targetPosition = target.offsetTop - headerHeight;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
}

/**
 * Initialize animations and scroll effects
 */
function initializeAnimations() {
    // Intersection Observer for fade-in animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Observe elements for animation
    const animatedElements = document.querySelectorAll('.step, .platform-card, .benefit-card, .faq-item, .feature-item, .coverage-item, .value-item');
    
    animatedElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
}

/**
 * Show notification
 */
function showNotification(message, type = 'info') {
    // Remove existing notifications
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => notification.remove());
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    
    // Create content safely using DOM methods instead of innerHTML
    const contentDiv = document.createElement('div');
    contentDiv.className = 'notification-content';
    
    const icon = document.createElement('i');
    icon.className = `fas ${getNotificationIcon(type)}`;
    
    const messageSpan = document.createElement('span');
    messageSpan.textContent = message; // Use textContent to prevent XSS
    
    const closeButton = document.createElement('button');
    closeButton.className = 'notification-close';
    closeButton.onclick = function() { this.parentElement.parentElement.remove(); };
    
    const closeIcon = document.createElement('i');
    closeIcon.className = 'fas fa-times';
    closeButton.appendChild(closeIcon);
    
    contentDiv.appendChild(icon);
    contentDiv.appendChild(messageSpan);
    contentDiv.appendChild(closeButton);
    notification.appendChild(contentDiv);
    
    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: ${getNotificationColor(type)};
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 0.5rem;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        z-index: 10000;
        animation: slideInRight 0.3s ease;
        max-width: 400px;
        font-size: 0.9rem;
    `;
    
    // Add to page
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }
    }, 5000);
}

/**
 * Get notification icon based on type
 */
function getNotificationIcon(type) {
    const icons = {
        success: 'fa-check-circle',
        error: 'fa-exclamation-circle',
        warning: 'fa-exclamation-triangle',
        info: 'fa-info-circle'
    };
    return icons[type] || icons.info;
}

/**
 * Get notification color based on type
 */
function getNotificationColor(type) {
    const colors = {
        success: 'hsl(142, 71%, 45%)',
        error: 'hsl(0, 84%, 60%)',
        warning: 'hsl(45, 93%, 58%)',
        info: 'hsl(210, 100%, 50%)'
    };
    return colors[type] || colors.info;
}

/**
 * Add notification animations to page
 */
function addNotificationStyles() {
    if (!document.querySelector('#notification-styles')) {
        const style = document.createElement('style');
        style.id = 'notification-styles';
        style.textContent = `
            @keyframes slideInRight {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
            
            @keyframes slideOutRight {
                from {
                    transform: translateX(0);
                    opacity: 1;
                }
                to {
                    transform: translateX(100%);
                    opacity: 0;
                }
            }
            
            .notification-content {
                display: flex;
                align-items: center;
                gap: 0.75rem;
            }
            
            .notification-close {
                background: none;
                border: none;
                color: inherit;
                cursor: pointer;
                padding: 0;
                margin-left: auto;
                opacity: 0.8;
                transition: opacity 0.2s ease;
            }
            
            .notification-close:hover {
                opacity: 1;
            }
        `;
        document.head.appendChild(style);
    }
}

// Initialize notification styles
addNotificationStyles();

/**
 * Utility functions
 */

// Debounce function for performance optimization
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Throttle function for scroll events
function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// Performance optimization for scroll events
window.addEventListener('scroll', throttle(() => {
    // Handle scroll-based animations here if needed
}, 16)); // ~60fps

// Handle page visibility changes
document.addEventListener('visibilitychange', function() {
    if (document.visibilityState === 'hidden') {
        // Pause any ongoing processes when page is hidden
        console.log('Page hidden - pausing processes');
    } else {
        // Resume processes when page becomes visible
        console.log('Page visible - resuming processes');
    }
});

// Error handling for uncaught errors
window.addEventListener('error', function(e) {
    console.error('Uncaught error:', e.error);
    showNotification('An unexpected error occurred. Please try again.', 'error');
});

// Handle unhandled promise rejections
window.addEventListener('unhandledrejection', function(e) {
    console.error('Unhandled promise rejection:', e.reason);
    showNotification('An unexpected error occurred. Please try again.', 'error');
});

// Export functions for testing (if in test environment)
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        isValidVideoUrl,
        isValidEmail,
        validateField,
        extractVideoTitle
    };
}
