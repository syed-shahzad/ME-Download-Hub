#!/usr/bin/env python3
"""
ME Downloader - Unified Server
Serves static files and handles video download API
"""

import os
import json
import tempfile
import shutil
from flask import Flask, request, jsonify, send_file, send_from_directory
from flask_cors import CORS
import yt_dlp
from urllib.parse import urlparse
import uuid

app = Flask(__name__, static_folder='.')
CORS(app)

# Configure download directory
DOWNLOAD_DIR = tempfile.mkdtemp()

class VideoDownloader:
    def __init__(self):
        # Extended list of supported domains - yt-dlp supports 1000+ sites
        self.supported_domains = [
            # Major platforms
            'youtube.com', 'youtu.be', 'm.youtube.com',
            'tiktok.com', 'vm.tiktok.com',
            'facebook.com', 'fb.watch', 'm.facebook.com',
            'twitter.com', 'x.com', 'mobile.twitter.com',
            'instagram.com', 'www.instagram.com',
            # Additional social platforms
            'reddit.com', 'v.redd.it', 'www.reddit.com',
            'vimeo.com', 'player.vimeo.com',
            'twitch.tv', 'clips.twitch.tv', 'm.twitch.tv',
            'dailymotion.com', 'dai.ly',
            'linkedin.com', 'www.linkedin.com',
            'pinterest.com', 'pin.it',
            # Video hosting platforms
            'streamable.com', 'gfycat.com', 'imgur.com',
            'soundcloud.com', 'mixcloud.com',
            'bitchute.com', 'rumble.com',
            'odysee.com', 'lbry.tv',
            # News and media sites
            'cnn.com', 'bbc.co.uk', 'bbc.com',
            'reuters.com', 'bloomberg.com',
            'washingtonpost.com', 'nytimes.com',
            # Educational platforms
            'ted.com', 'coursera.org', 'udemy.com',
            'khanacademy.org', 'edx.org'
        ]
    
    def is_supported_url(self, url):
        """Check if URL is from supported platform or try universal extraction"""
        try:
            domain = urlparse(url).netloc.lower()
            # First check known supported domains
            if any(supported in domain for supported in self.supported_domains):
                return True
            
            # For unknown domains, we'll let yt-dlp try universal extraction
            # yt-dlp has generic extractors that work with many sites
            return True  # Universal support - let yt-dlp handle validation
        except:
            return False
    
    def get_video_info(self, url):
        """Extract video metadata without downloading"""
        ydl_opts = {
            'quiet': True,
            'no_warnings': True,
            'extract_flat': False,
            'user_agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'referer': 'https://www.youtube.com/',
            'http_headers': {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-us,en;q=0.5',
                'Accept-Encoding': 'gzip, deflate',
                'DNT': '1',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1'
            },
            'extractor_args': {
                'youtube': {
                    'skip': ['dash', 'hls'],
                    'player_skip': ['js']
                }
            },
            'cookiefile': None,
            'no_check_certificate': True
        }
        
        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=False)
                if info is None:
                    raise Exception("Could not extract video information")
                    
                return {
                    'title': info.get('title', 'Unknown Title'),
                    'duration': info.get('duration', 0),
                    'uploader': info.get('uploader', 'Unknown'),
                    'thumbnail': info.get('thumbnail', ''),
                    'formats': len(info.get('formats', [])),
                    'platform': self.detect_platform(url)
                }
        except Exception as e:
            raise Exception(f"Failed to extract video info: {str(e)}")
    
    def detect_platform(self, url):
        """Detect platform from URL"""
        url_lower = url.lower()
        if 'youtube.com' in url_lower or 'youtu.be' in url_lower:
            return 'youtube'
        elif 'tiktok.com' in url_lower:
            return 'tiktok'
        elif 'facebook.com' in url_lower or 'fb.watch' in url_lower:
            return 'facebook'
        elif 'twitter.com' in url_lower or 'x.com' in url_lower:
            return 'twitter'
        elif 'instagram.com' in url_lower:
            return 'instagram'
        elif 'reddit.com' in url_lower or 'v.redd.it' in url_lower:
            return 'reddit'
        elif 'vimeo.com' in url_lower:
            return 'vimeo'
        elif 'twitch.tv' in url_lower:
            return 'twitch'
        elif 'dailymotion.com' in url_lower or 'dai.ly' in url_lower:
            return 'dailymotion'
        elif 'linkedin.com' in url_lower:
            return 'linkedin'
        elif 'pinterest.com' in url_lower or 'pin.it' in url_lower:
            return 'pinterest'
        elif 'streamable.com' in url_lower:
            return 'streamable'
        elif 'soundcloud.com' in url_lower:
            return 'soundcloud'
        elif 'ted.com' in url_lower:
            return 'ted'
        else:
            return 'website'
    
    def download_video(self, url, format_type='mp4', quality='best'):
        """Download video/audio and return file path"""
        download_id = str(uuid.uuid4())
        
        # Configure format based on user selection
        if format_type == 'mp3':
            ydl_opts = {
                'outtmpl': os.path.join(DOWNLOAD_DIR, f'{download_id}.%(ext)s'),
                'format': 'bestaudio/best',
                'postprocessors': [{
                    'key': 'FFmpegExtractAudio',
                    'preferredcodec': 'mp3',
                    'preferredquality': '192',
                }],
                'quiet': True,
                'no_warnings': True,
                'user_agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                'referer': 'https://www.youtube.com/',
                'http_headers': {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-us,en;q=0.5',
                    'Accept-Encoding': 'gzip, deflate',
                    'DNT': '1',
                    'Connection': 'keep-alive',
                    'Upgrade-Insecure-Requests': '1'
                },
                'extractor_args': {
                    'youtube': {
                        'skip': ['dash', 'hls'],
                        'player_skip': ['js']
                    }
                },
                'cookiefile': None,
                'no_check_certificate': True
            }
        else:
            # Video formats with quality selection - more flexible fallback options
            format_options = {
                'best': 'best[height<=?1080]/best[height<=?720]/best',
                'hd': 'best[height<=?720]/best[height<=?480]/best',
                'sd': 'best[height<=?480]/best[height<=?360]/best',
                '4k': 'best[height<=?2160]/best[height<=?1080]/best',
                'mp4': 'best[ext=mp4][height<=?1080]/best[ext=mp4]/best',
                'webm': 'best[ext=webm][height<=?1080]/best[ext=webm]/best',
                'avi': 'best[ext=avi][height<=?1080]/best[ext=avi]/best'
            }
            
            selected_format = format_options.get(quality, 'best[height<=?1080]/best')
            
            ydl_opts = {
                'outtmpl': os.path.join(DOWNLOAD_DIR, f'{download_id}.%(ext)s'),
                'format': selected_format,
                'quiet': True,
                'no_warnings': True,
                'ignoreerrors': False,
                'user_agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                'referer': 'https://www.youtube.com/',
                'http_headers': {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-us,en;q=0.5',
                    'Accept-Encoding': 'gzip, deflate',
                    'DNT': '1',
                    'Connection': 'keep-alive',
                    'Upgrade-Insecure-Requests': '1'
                },
                'extractor_args': {
                    'youtube': {
                        'skip': ['dash', 'hls'],
                        'player_skip': ['js']
                    }
                },
                'cookiefile': None,
                'no_check_certificate': True
            }
        
        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=True)
                if info is None:
                    raise Exception("Could not extract video information for download")
                
                # For MP3, the file extension changes after post-processing
                if format_type == 'mp3':
                    base_filename = os.path.join(DOWNLOAD_DIR, download_id)
                    mp3_filename = f"{base_filename}.mp3"
                    if os.path.exists(mp3_filename):
                        filename = mp3_filename
                    else:
                        # Fallback to original filename
                        filename = ydl.prepare_filename(info)
                else:
                    filename = ydl.prepare_filename(info)
                
                if os.path.exists(filename):
                    return {
                        'file_path': filename,
                        'title': info.get('title', 'video'),
                        'ext': 'mp3' if format_type == 'mp3' else info.get('ext', 'mp4'),
                        'filesize': os.path.getsize(filename),
                        'format_type': format_type,
                        'quality': quality
                    }
                else:
                    raise Exception("Download completed but file not found")
                    
        except Exception as e:
            error_msg = str(e)
            # Provide more user-friendly error messages
            if "Requested format is not available" in error_msg:
                raise Exception("The requested video quality is not available for this video. Please try a different quality option.")
            elif "Video unavailable" in error_msg:
                raise Exception("This video is not available for download (may be private, deleted, or region-restricted).")
            elif "Sign in to confirm your age" in error_msg:
                raise Exception("This video requires age verification and cannot be downloaded.")
            elif "This video is only available for Music Premium members" in error_msg:
                raise Exception("This video is restricted to premium members only.")
            elif "Unable to extract" in error_msg:
                raise Exception("Unable to extract video information. The video may be protected or the URL may be invalid.")
            else:
                raise Exception(f"Download failed: {error_msg}")

downloader = VideoDownloader()

# Serve static files
@app.route('/')
def serve_index():
    return send_from_directory('.', 'index.html')

@app.route('/<path:filename>')
def serve_static(filename):
    return send_from_directory('.', filename)

# API Routes
@app.route('/api/check-url', methods=['POST'])
def check_url():
    """Check if URL is valid and get video info"""
    try:
        data = request.get_json()
        url = data.get('url', '').strip()
        
        if not url:
            return jsonify({'error': 'URL is required'}), 400
        
        if not downloader.is_supported_url(url):
            return jsonify({'error': 'Unsupported platform or invalid URL'}), 400
        
        video_info = downloader.get_video_info(url)
        
        return jsonify({
            'valid': True,
            'info': video_info
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/download', methods=['POST'])
def download_video():
    """Download video/audio and return download link"""
    try:
        data = request.get_json()
        url = data.get('url', '').strip()
        format_type = data.get('format', 'mp4')
        quality = data.get('quality', 'best')
        
        if not url:
            return jsonify({'error': 'URL is required'}), 400
        
        if not downloader.is_supported_url(url):
            return jsonify({'error': 'Unsupported platform or invalid URL'}), 400
        
        result = downloader.download_video(url, format_type, quality)
        
        return jsonify({
            'success': True,
            'download_id': os.path.basename(result['file_path']).split('.')[0],
            'title': result['title'],
            'filesize': result['filesize'],
            'format': result['ext'],
            'format_type': result['format_type'],
            'quality': result['quality']
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/file/<download_id>')
def get_file(download_id):
    """Serve downloaded file"""
    try:
        for filename in os.listdir(DOWNLOAD_DIR):
            if filename.startswith(download_id):
                file_path = os.path.join(DOWNLOAD_DIR, filename)
                return send_file(
                    file_path,
                    as_attachment=True,
                    download_name=filename
                )
        
        return jsonify({'error': 'File not found'}), 404
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/platforms')
def get_supported_platforms():
    """Get list of supported platforms"""
    return jsonify({
        'platforms': [
            {'id': 'youtube', 'name': 'YouTube', 'domains': ['youtube.com', 'youtu.be', 'm.youtube.com']},
            {'id': 'tiktok', 'name': 'TikTok', 'domains': ['tiktok.com', 'vm.tiktok.com']},
            {'id': 'facebook', 'name': 'Facebook', 'domains': ['facebook.com', 'fb.watch', 'm.facebook.com']},
            {'id': 'twitter', 'name': 'Twitter/X', 'domains': ['twitter.com', 'x.com', 'mobile.twitter.com']},
            {'id': 'instagram', 'name': 'Instagram', 'domains': ['instagram.com', 'www.instagram.com']},
            {'id': 'reddit', 'name': 'Reddit', 'domains': ['reddit.com', 'v.redd.it', 'www.reddit.com']},
            {'id': 'vimeo', 'name': 'Vimeo', 'domains': ['vimeo.com', 'player.vimeo.com']},
            {'id': 'twitch', 'name': 'Twitch', 'domains': ['twitch.tv', 'clips.twitch.tv', 'm.twitch.tv']},
            {'id': 'dailymotion', 'name': 'Dailymotion', 'domains': ['dailymotion.com', 'dai.ly']},
            {'id': 'linkedin', 'name': 'LinkedIn', 'domains': ['linkedin.com', 'www.linkedin.com']},
            {'id': 'pinterest', 'name': 'Pinterest', 'domains': ['pinterest.com', 'pin.it']},
            {'id': 'streamable', 'name': 'Streamable', 'domains': ['streamable.com']},
            {'id': 'soundcloud', 'name': 'SoundCloud', 'domains': ['soundcloud.com']},
            {'id': 'ted', 'name': 'TED Talks', 'domains': ['ted.com']},
            {'id': 'universal', 'name': 'Any Website', 'domains': ['*'], 'description': 'Universal support for 1000+ websites'}
        ],
        'total_supported': '1000+',
        'description': 'Universal video downloader supporting virtually any website with embedded videos'
    })

@app.route('/health')
def health_check():
    return jsonify({'status': 'healthy', 'service': 'ME Download Hub'})

# Cleanup function
import atexit
def cleanup():
    try:
        shutil.rmtree(DOWNLOAD_DIR)
    except:
        pass

atexit.register(cleanup)

if __name__ == '__main__':
    print(f"ME Download Hub starting...")
    print(f"Universal video downloader supporting 1000+ websites")
    print(f"Download directory: {DOWNLOAD_DIR}")
    app.run(host='0.0.0.0', port=5000, debug=False)