#!/usr/bin/env python3
"""
ME Downloader Backend Server
Real video downloading service using yt-dlp
"""

import os
import json
import tempfile
import shutil
from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import yt_dlp
from urllib.parse import urlparse
import re

app = Flask(__name__)
CORS(app)

# Configure download directory
DOWNLOAD_DIR = tempfile.mkdtemp()

class VideoDownloader:
    def __init__(self):
        self.supported_domains = [
            'youtube.com', 'youtu.be',
            'tiktok.com',
            'facebook.com', 'fb.watch',
            'twitter.com', 'x.com',
            'instagram.com'
        ]
    
    def is_supported_url(self, url):
        """Check if URL is from supported platform"""
        try:
            domain = urlparse(url).netloc.lower()
            return any(supported in domain for supported in self.supported_domains)
        except:
            return False
    
    def get_video_info(self, url):
        """Extract video metadata without downloading"""
        ydl_opts = {
            'quiet': True,
            'no_warnings': True,
            'extract_flat': False,
        }
        
        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=False)
                if info is None:
                    raise Exception("Could not extract video information")
                    
                return {
                    'title': info.get('title', 'Unknown Title'),
                    'duration': info.get('duration', 0),
                    'uploader': info.get('uploader', 'Unknown'),
                    'thumbnail': info.get('thumbnail', ''),
                    'formats': len(info.get('formats', [])),
                    'platform': self.detect_platform(url)
                }
        except Exception as e:
            raise Exception(f"Failed to extract video info: {str(e)}")
    
    def detect_platform(self, url):
        """Detect platform from URL"""
        url_lower = url.lower()
        if 'youtube.com' in url_lower or 'youtu.be' in url_lower:
            return 'youtube'
        elif 'tiktok.com' in url_lower:
            return 'tiktok'
        elif 'facebook.com' in url_lower or 'fb.watch' in url_lower:
            return 'facebook'
        elif 'twitter.com' in url_lower or 'x.com' in url_lower:
            return 'twitter'
        elif 'instagram.com' in url_lower:
            return 'instagram'
        return 'unknown'
    
    def download_video(self, url, quality='best'):
        """Download video and return file path"""
        # Create unique filename
        import uuid
        download_id = str(uuid.uuid4())
        
        ydl_opts = {
            'outtmpl': os.path.join(DOWNLOAD_DIR, f'{download_id}.%(ext)s'),
            'format': quality,
            'quiet': True,
            'no_warnings': True,
        }
        
        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=True)
                if info is None:
                    raise Exception("Could not extract video information for download")
                
                # Find the downloaded file
                filename = ydl.prepare_filename(info)
                if os.path.exists(filename):
                    return {
                        'file_path': filename,
                        'title': info.get('title', 'video'),
                        'ext': info.get('ext', 'mp4'),
                        'filesize': os.path.getsize(filename)
                    }
                else:
                    raise Exception("Download completed but file not found")
                    
        except Exception as e:
            raise Exception(f"Download failed: {str(e)}")

downloader = VideoDownloader()

@app.route('/api/check-url', methods=['POST'])
def check_url():
    """Check if URL is valid and get video info"""
    try:
        data = request.get_json()
        url = data.get('url', '').strip()
        
        if not url:
            return jsonify({'error': 'URL is required'}), 400
        
        if not downloader.is_supported_url(url):
            return jsonify({'error': 'Unsupported platform or invalid URL'}), 400
        
        # Get video info
        video_info = downloader.get_video_info(url)
        
        return jsonify({
            'valid': True,
            'info': video_info
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/download', methods=['POST'])
def download_video():
    """Download video and return download link"""
    try:
        data = request.get_json()
        url = data.get('url', '').strip()
        quality = data.get('quality', 'best')
        
        if not url:
            return jsonify({'error': 'URL is required'}), 400
        
        if not downloader.is_supported_url(url):
            return jsonify({'error': 'Unsupported platform or invalid URL'}), 400
        
        # Download video
        result = downloader.download_video(url, quality)
        
        return jsonify({
            'success': True,
            'download_id': os.path.basename(result['file_path']).split('.')[0],
            'title': result['title'],
            'filesize': result['filesize'],
            'format': result['ext']
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/file/<download_id>')
def get_file(download_id):
    """Serve downloaded file"""
    try:
        # Find file with this ID
        for filename in os.listdir(DOWNLOAD_DIR):
            if filename.startswith(download_id):
                file_path = os.path.join(DOWNLOAD_DIR, filename)
                return send_file(
                    file_path,
                    as_attachment=True,
                    download_name=filename
                )
        
        return jsonify({'error': 'File not found'}), 404
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/platforms')
def get_supported_platforms():
    """Get list of supported platforms"""
    return jsonify({
        'platforms': [
            {
                'id': 'youtube',
                'name': 'YouTube',
                'domains': ['youtube.com', 'youtu.be'],
                'icon': 'fab fa-youtube'
            },
            {
                'id': 'tiktok',
                'name': 'TikTok',
                'domains': ['tiktok.com'],
                'icon': 'fab fa-tiktok'
            },
            {
                'id': 'facebook',
                'name': 'Facebook',
                'domains': ['facebook.com', 'fb.watch'],
                'icon': 'fab fa-facebook'
            },
            {
                'id': 'twitter',
                'name': 'Twitter/X',
                'domains': ['twitter.com', 'x.com'],
                'icon': 'fab fa-twitter'
            },
            {
                'id': 'instagram',
                'name': 'Instagram',
                'domains': ['instagram.com'],
                'icon': 'fab fa-instagram'
            }
        ]
    })

@app.route('/health')
def health_check():
    """Health check endpoint"""
    return jsonify({'status': 'healthy', 'service': 'ME Downloader API'})

# Cleanup function
import atexit
def cleanup():
    """Clean up temporary files on exit"""
    try:
        shutil.rmtree(DOWNLOAD_DIR)
    except:
        pass

atexit.register(cleanup)

if __name__ == '__main__':
    print(f"ME Downloader API starting...")
    print(f"Download directory: {DOWNLOAD_DIR}")
    app.run(host='0.0.0.0', port=5001, debug=True)